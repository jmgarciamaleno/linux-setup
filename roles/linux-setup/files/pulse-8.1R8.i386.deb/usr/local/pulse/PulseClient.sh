HOMEDIR=$HOME
INSTALLDIR=/usr/local/pulse
PULSEDIR=$HOME/.pulse_secure/pulse
SVCNAME=pulsesvc
LOG=$PULSEDIR/PulseClient.log
args=""
ive_ip=""

######################################################################################################
# Function to verify if dependencies are installed
# Args   : None
# Return : None
#function check_dep () 
#{
RPM_DIST=0
DPKG_DIST=0
# If script is shipped as part of RPM, then 
# following will be present. 
uname -a | grep -i "i386\|i486\|i586\|i686" >/dev/null
if [ $? -ne 0 ]; then 
if [ -e $INSTALLDIR/ConfigurePulse.sh ]; then 
    RPM_DIST=1
else
    DPKG_DIST=1
fi 
if [ $RPM_DIST -eq 1 ]; then 
    PKGREQ=""
    glibc=`rpm -qa | grep -i glibc | grep -i "i686\|i386"`
    if [ "X$glibc" = "X" ]; then
        echo "glibc is missing in the machine" > $LOG
        PKGREQ="glibc.i686"
    fi  
    nss=`rpm -qa | grep -i nss-softokn-freebl | grep -i "i386\|i686"`
    if [ "X$nss" = "X" ]; then 
        echo "nss is missing in the machine" > $LOG
        PKGREQ="$PKGREQ nss.i686"
    fi  
    zlib=`rpm -qa | grep -i zlib | grep -i "i386\|i686"`
    if [ "X$zlib" = "X" ]; then 
        echo "zlib is missing in the machine" > $LOG
        PKGREQ="$PKGREQ zlib.i686"
    fi
    if [ "X" != "X$PKGREQ" ]; then
        sudo -v > /dev/null 2>/dev/null
        if [ $? -eq 0 ]; then 
            echo "sudo password "
            sudo yum -y install $PKGREQ
            if [ $? -ne 0 ]; then
                echo "Failed to install dependencies.Please execute following command manually."
                echo " yum install $PKGREQ"
            fi
        else 
            echo "super user password "
            su -c "yum -y install $PKGREQ"
            if [ $? -ne 0 ]; then
                echo "Failed to install dependencies.Please execute following command manually."
                echo " yum install $PKGREQ"
            fi
        fi 
    fi
elif [ $DPKG_DIST -eq 1 ]; then 
    PKGREQ=""
    libc=`dpkg-query -f '${binary:Package}\n' -W | grep -i libc6-i386`
    if [ "X$libc" = "X" ]; then 
        PKGREQ="libc6-i386"
    fi  
    zlib=`dpkg-query -f '${binary:Package}\n' -W | grep -i lib32z1`
    if [ "X$zlib" = "X" ]; then 
        PKGREQ="$PKGREQ lib32z1"
    fi
    if [ "X" != "X$PKGREQ" ]; then
        sudo -v > /dev/null 2>/dev/null
        if [ $? -eq 0 ]; then 
            echo "sudo password : "
            sudo apt-get install $PKGREQ 
            if [ $? -ne 0 ]; then
                echo "Failed to install dependencies.Please execute following command manually."
                echo " apt-get install $PKGREQ"
            fi
        else 
            echo "super user password : "
            su -c "apt-get install $PKGREQ"
            if [ $? -ne 0 ]; then
                echo "Failed to install dependencies.Please execute following command manually."
                echo " apt-get install $PKGREQ"
            fi
        fi
    fi
fi 
fi 
#}
#End of function check_dep () 
######################################################################################################

######################################################################################################
# Function to create user specific installation 
# Args   : None
# Return : None
#function check_install () 
#{
if [ ! -e $INSTALLDIR ]; then 
   echo "Pulse is not installed. Please check if Pulse is installed properly"
   exit 1
fi 
# create $HOME/.pulse_secure/pulse/ directory 
if [ ! -d $PULSEDIR ]; then 
    mkdir -p $PULSEDIR
    if [ $? -ne 0 ]; then 
        echo "Setup is not able to create $PULSEDIR. Please check the permission"
        exit 2
    fi 
fi
#}
# End of function check_install ()
######################################################################################################

if [ $# -gt 0 ]; then 
	args="$@"
else
        $INSTALLDIR/$SVCNAME -C -H
	exit 0
fi

echo "executing command : $INSTALLDIR/$SVCNAME $args" 
# -C option added to indicate service is launched from command line - hidden option
#args="-C $args"
# pass the args to pulsesvc binary 
$INSTALLDIR/$SVCNAME -C "${@}"
